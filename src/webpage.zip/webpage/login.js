import React, { useState} from "react";

function Login({ onLogin = () => {} }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignup, setIsSignup] = useState(false);

  const handleSubmit = () => {
    if (email && password) {
      if (isSignup) {
        alert(`Account created for ${email}! 🎉`);
        setIsSignup(false); // go back to login after signup
      } else {
        onLogin(email);
      }
    } else {
      alert("Please enter both email and password!");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.overlay}></div>

      <div style={styles.loginCard}>
        <h2>{isSignup ? "Create Account" : "Realtime Chatroom"}</h2>

        <input
          type="text"
          style={styles.input}
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          style={styles.input}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {isSignup && (
          <input
            type="password"
            placeholder="Confirm Password"
            style={styles.input}
          />
        )}

        <button style={styles.button} onClick={handleSubmit}>
          {isSignup ? "Sign Up" : "Login"}
        </button>

        <p>
          {isSignup ? "Already have an account? " : "Don't have an account? "}
          <span
            style={styles.signup}
            onClick={() => setIsSignup(!isSignup)}
          >
            {isSignup ? "Login" : "Sign up"}
          </span>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    position: "relative",
    height: "100vh",
    width: "100%",
    background:
      "url('https://images.unsplash.com/photo-1603791440384-56cd371ee9a7?auto=format&fit=crop&w=1950&q=80') no-repeat center center/cover",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },
  overlay: {
    position: "absolute",
    inset: 0,
    background: "rgba(0,0,0,0.5)",
  },
  loginCard: {
    position: "relative",
    zIndex: 2,
    background: "rgba(255,255,255,0.9)",
    padding: "2rem",
    borderRadius: "16px",
    width: "350px",
    textAlign: "center",
    boxShadow: "0 8px 25px rgba(0,0,0,0.2)",
    animation: "fadeIn 1s ease-out",
  },
  input: {
    width: "100%",
    padding: "10px",
    marginBottom: "15px",
    border: "1px solid #d1d5db",
    borderRadius: "8px",
    outline: "none",
    transition: "border 0.2s",
  },
  signup: {
    color: "#6366f1",
    fontWeight: "bold",
    cursor: "pointer",
  },
  button: {
    position: "relative",
    zindex: "0",
    padding: "12px 40px",
    color: "white",
    background: "black",
    border: "none",
    borderradius: "12px",
    fontsize: "16px",
    fontweight: "bold",
    cursor: "pointer",
    overflow: "hidden",
  },
};

export default Login;
